#!/bin/bash
cd /usr/project/mjpg-streamer-code/mjpg-streamer-experimental
fuser 8080/tcp
fuser -k 8080/tcp
./mjpg_streamer -i "./input_uvc.so -n -f 15 -r 640x480" -o "./output_http.so -n -w ./www"
